import React from "react";

export const EncabezadoChat = ({ chatActivo }) => {
  return <div className="encabezadoChat mb-3">{chatActivo}</div>;
};
