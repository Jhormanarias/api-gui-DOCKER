# Proyecto en REACT de pokemon

_Qúe es el consumo de la api de pokemon y poder mostrarme los pokemon_

## Comenzando 🚀

_Recuerda que este proyecto no funciona sin los módulos necesarios, si es necesario crea una app nueva de react con el comando "NPX create-react-app nombre-que-le-quieras-poner" y copias y pegas los archivos de este proyecto en el nuevo que creaste._

### Ejecución 📦

_Ejecutalo con el comando "npm start"_



## Construido con 🛠️

_Menciona las herramientas que utilizaste para crear tu proyecto_

* [Bootsrap(https://getbootstrap.com/docs/5.1/getting-started/introduction/) - El framework web usado
* [node-js] - Manejador de dependencias
* [REACT](https://rometools.github.io/rome/) - Framework usado
* Visual Studio Code

## Autores ✒️

* **Jhorman Gañan Arias** - *Trabajo de todo el proyecto* - [Project React Pokemon](https://github.com/Jhormanarias/

---
⌨️
